class Animal {
  public void animalSound() {
    System.out.println("The animal makes a sound");
  }
}

class Pig extends Animal {
  public void animalSound() {
    System.out.println("The pig says: wee wee");
  }
}

class Dog extends Animal {
  public void animalSound() {
    System.out.println("The dog says: woof woof");
  }
}

class Cat extends Animal {
  public void animalSound() {
    System.out.println("The Cat says: meow");
  }
}

public class mainClass
{
  public static void main(String [] args)
  {
    Animal pigObj = new Pig();
    Animal catObj = new Cat();
    Animal dogObj = new Dog();
    
    pigObj.animalSound();
    catObj.animalSound();
    dogObj.animalSound();
    
    
  }
}